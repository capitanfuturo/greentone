/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import org.datanucleus.query.typesafe.BooleanExpression;
import org.datanucleus.query.typesafe.ComparableExpression;
import org.datanucleus.query.typesafe.NumericExpression;
import org.datanucleus.query.typesafe.OrderExpression;

/**
 * Implementation of the methods for ComparableExpression.
 */
public class ComparableExpressionImpl<T> extends ExpressionImpl<T> implements ComparableExpression<T>
{
    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#gt(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression gt(ComparableExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#gt(java.lang.Object)
     */
    public BooleanExpression gt(T t)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#gteq(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression gteq(ComparableExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#gteq(java.lang.Object)
     */
    public BooleanExpression gteq(T t)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#lt(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression lt(ComparableExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#lt(java.lang.Object)
     */
    public BooleanExpression lt(T t)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#lteq(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression lteq(ComparableExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#lteq(java.lang.Object)
     */
    public BooleanExpression lteq(T t)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#max()
     */
    public NumericExpression max()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#min()
     */
    public NumericExpression min()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#asc()
     */
    public OrderExpression asc()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#desc()
     */
    public OrderExpression desc()
    {
        // TODO Auto-generated method stub
        return null;
    }
}