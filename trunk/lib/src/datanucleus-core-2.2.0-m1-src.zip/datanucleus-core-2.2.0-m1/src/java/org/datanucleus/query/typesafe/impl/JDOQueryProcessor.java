/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import java.io.IOException;
import java.io.Writer;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.jdo.annotations.PersistenceCapable;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;
import javax.tools.JavaFileObject;

/**
 * Annotation processor for JDO to generate "dummy" classes for all persistable classes for use with the 
 * Typesafe Query API. Any class ({MyClass}) that has a JDO "class" annotation will have a stub class 
 * (Q{MyClass}) generated.
 * <ul>
 * <li>For each managed class X in package p, a metamodel class QX in package p is created.</li>
 * <li>The name of the metamodel class is derived from the name of the managed class by prepending "Q" 
 * to the name of the managed class.</li>
 * </ul>
 */
@SupportedAnnotationTypes({"javax.jdo.annotations.PersistenceCapable"})
@SupportedSourceVersion(SourceVersion.RELEASE_6)
public class JDOQueryProcessor extends AbstractProcessor
{
    String prefix = "Q";

    Types typesHandler;

    /* (non-Javadoc)
     * @see javax.annotation.processing.AbstractProcessor#process(java.util.Set, javax.annotation.processing.RoundEnvironment)
     */
    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv)
    {
        if (roundEnv.processingOver())
        {
            return false;
        }

        typesHandler = processingEnv.getTypeUtils();
        Set<? extends Element> elements = roundEnv.getRootElements();
        for (Element e : elements)
        {
            processClass((TypeElement)e);
        }
        return false;
    }

    /**
     * Handler for processing a JDO annotated class to create the criteria class stub.
     * @param el The class element
     */
    protected void processClass(TypeElement el)
    {
        if (el == null || !isJDOAnnotated(el))
        {
            return;
        }

        // TODO Set imports to only include the classes we require
        // TODO Set references to other classes to be the class name and put the package in the imports
        // TODO Support specification of the location for writing the class source files
        Elements elementUtils = processingEnv.getElementUtils();
        String className = elementUtils.getBinaryName(el).toString();
        String pkgName = className.substring(0, className.lastIndexOf('.'));
        String classSimpleName = className.substring(className.lastIndexOf('.') + 1);
        String classNameNew = prefix + className;
        System.out.println("JDO QueryProcessor orig=" + className + " new=" + classNameNew);

        TypeElement superEl = getPersistentSupertype(el);
        try
        {
            JavaFileObject javaFile = processingEnv.getFiler().createSourceFile(classNameNew);
            Writer w = javaFile.openWriter();
            try
            {
                w.append("package " + pkgName + ";\n");
                w.append("\n");
                w.append("public class " + prefix + classSimpleName);
                if (superEl != null)
                {
                    String superClassName = elementUtils.getBinaryName(superEl).toString();
                    w.append(" extends ").append(prefix + superClassName);
                }
                // TODO implements PathExpression
                w.append("\n");
                w.append("{\n");

                // Find the members to use for persistence processing

                w.append("}\n");
                w.flush();
            }
            finally
            {
                w.close();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    /**
     * Method to find the next persistent supertype above this one.
     * @param element The element
     * @return Its next parent that is persistable (or null if no persistable predecessors)
     */
    public TypeElement getPersistentSupertype(TypeElement element)
    {
        TypeMirror superType = element.getSuperclass();
        if (superType == null || (element != null && "java.lang.Object".equals(element.toString())))
        {
            return null;
        }

        TypeElement superElement = (TypeElement) processingEnv.getTypeUtils().asElement(superType);
        if (isJDOAnnotated(superElement))
        {
            return superElement;
        }
        return getPersistentSupertype(superElement);
    }

    /**
     * Convenience method to return if this class element has any of the defining JDO annotations.
     * @param el The class element
     * @return Whether it is to be considered a JDO annotated class
     */
    public static boolean isJDOAnnotated(TypeElement el)
    {
        if ((el.getAnnotation(PersistenceCapable.class) != null))
        {
            return true;
        }
        return false;
    }
}