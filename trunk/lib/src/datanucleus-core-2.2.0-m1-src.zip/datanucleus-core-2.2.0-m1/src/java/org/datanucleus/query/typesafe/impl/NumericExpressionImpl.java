/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import org.datanucleus.query.typesafe.Expression;
import org.datanucleus.query.typesafe.NumericExpression;

/**
 * Implementation of a NumericExpression.
 */
public class NumericExpressionImpl<T> extends ComparableExpressionImpl<Number> implements NumericExpression<T>
{
    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#add(org.datanucleus.query.typesafe.Expression)
     */
    public NumericExpression add(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#add(java.lang.Number)
     */
    public NumericExpression add(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#mul(org.datanucleus.query.typesafe.Expression)
     */
    public NumericExpression mul(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#mul(java.lang.Number)
     */
    public NumericExpression mul(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#sub(org.datanucleus.query.typesafe.Expression)
     */
    public NumericExpression sub(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#sub(java.lang.Number)
     */
    public NumericExpression sub(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#div(org.datanucleus.query.typesafe.Expression)
     */
    public NumericExpression div(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#div(java.lang.Number)
     */
    public NumericExpression div(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#mod(org.datanucleus.query.typesafe.Expression)
     */
    public NumericExpression mod(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#mod(java.lang.Number)
     */
    public NumericExpression mod(Number num)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#avg()
     */
    public NumericExpression avg()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#sum()
     */
    public NumericExpression sum()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#abs()
     */
    public NumericExpression abs()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.NumericExpression#sqrt()
     */
    public NumericExpression sqrt()
    {
        // TODO Auto-generated method stub
        return null;
    }
}