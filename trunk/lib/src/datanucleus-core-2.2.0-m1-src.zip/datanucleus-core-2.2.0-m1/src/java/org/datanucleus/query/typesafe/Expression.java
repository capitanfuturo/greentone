/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe;

/**
 * Representation of an expression in a query.
 * Use the <pre>getParentExpression()</pre> accessor to get the parent expression for this expression (if any).
 * If an expression is something like "a.b" then the parent expression will be "a" and the name here is "b".
 * 
 * @param <T> Java type being represented here
 */
public interface Expression<T>
{
    /**
     * Accessor for the path to this expression (alternatively known as the parent).
     * @return The (parent) path
     */
    PersistableExpression getParentExpression();

    /**
     * Accessor for the name for this expression, if applicable.
     * If this is a field/property of a persistable object then the <i>name</i> is the field/property name, 
     * if this is a parameter then the <i>name</i> is the parameter name,
     * and if this is a variable then the <i>name</i> is the variable name,
     * @return Name (if defined)
     */
    String name();

    /**
     * Get the Java type for this expression.
     * @return The java type
     */
    Class<? extends T> getType();

    /**
     * Method returning whether this expression equals the other expression.
     * @param expr Other expression
     * @return Whether they are equal
     */
    BooleanExpression eq(Expression expr);

    /**
     * Method returning whether this expression equals the literal.
     * @param t Literal
     * @return Whether they are equal
     */
    BooleanExpression eq(T t);

    /**
     * Method returning whether this expression doesn't equal the other expression.
     * @param expr Other expression
     * @return Whether they are not equal
     */
    BooleanExpression ne(Expression expr);

    /**
     * Method returning whether this expression doesn't equal the literal.
     * @param t literal
     * @return Whether they are not equal
     */
    BooleanExpression ne(T t);

    /**
     * Method to return a numeric expression representing the aggregated count of this expression.
     * @return Numeric expression for the count
     */
    NumericExpression<T> count();

    /**
     * Method to return a numeric expression representing the aggregated (distinct) count of this expression.
     * @return Numeric expression for the distinct count
     */
    NumericExpression<T> countDistinct();

    /**
     * Method to return this expression as a String form.
     * @return The string form
     */
    String toString();

    /**
     * Whether this expression represents a parameter.
     * @return Whether it is a parameter
     */
    boolean isParameter();

    /**
     * Whether this expression represents a variable.
     * @return Whether it is a variable
     */
    boolean isVariable();
}