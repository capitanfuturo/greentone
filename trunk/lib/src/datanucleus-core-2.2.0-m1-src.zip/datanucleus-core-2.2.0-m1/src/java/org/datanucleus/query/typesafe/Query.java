/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe;

import java.util.List;

import javax.jdo.FetchPlan;

/**
 * Interface for a type-safe query, using a fluent API.
 * Designed to handle JDO query requirements as a whole.
 */
public interface Query
{
    /**
     * Method to return an expression for the candidate of the query.
     * Cast the returned expression to the candidate "Q" type to be able to call methods on it.
     * @return Expression for the candidate
     */
    PersistableExpression candidate();

    /**
     * Method to return a parameter for the query.
     * Cast the returned parameter to the right type to be able to call methods on it.
     * @param name Name of the parameter
     * @param type Java type of the parameter
     * @return Expression for the parameter
     */
    Expression parameter(String name, Class type);

    /**
     * Method to return a variable for this query.
     * Cast the returned variable to the right type to be able to call methods on it.
     * @param name Name of the variable
     * @param type Type of the variable
     * @return Expression for the variable
     */
    Expression variable(String name, Class type);

    /**
     * Method to set the FetchPlan to use.
     * @param fp FetchPlan
     * @return The query
     */
    Query setFetchPlan(FetchPlan fp);

    /**
     * Method to set the filter of the query.
     * @param expr Filter expression
     * @return The query
     */
    Query filter(BooleanExpression expr);

    /**
     * Method to set the grouping(s) for the query.
     * @param exprs Grouping expression(s)
     * @return The query
     */
    Query groupBy(Expression... exprs);

    /**
     * Method to set the having clause of the query.
     * @param expr Having expression
     * @return The query
     */
    Query having(Expression expr);

    /**
     * Method to set the ordering of the query.
     * @param orderExprs Ordering expression(s)
     * @return The query
     */
    Query orderBy(OrderExpression... orderExprs);

    /**
     * Method to set the range of any required results, using expressions.
     * @param lowerInclExpr The position of the first result (inclusive)
     * @param upperExclExpr The position of the last result (exclusive)
     * @return The query
     */
    Query range(NumericExpression lowerInclExpr, NumericExpression upperExclExpr);

    /**
     * Method to set the range of any required results, using long values.
     * @param lowerIncl The position of the first result (inclusive)
     * @param upperExcl The position of the last result (exclusive)
     * @return The query
     */
    Query range(long lowerIncl, long upperExcl);

    /**
     * Method to set the range of any required results, using parameters.
     * @param paramLowerIncl The name of a parameter defining the position of the first result (inclusive)
     * @param paramUpperExcl The name of a parameter defining the position of the last result (exclusive)
     * @return The query
     */
    Query range(String paramLowerIncl, String paramUpperExcl);

    /**
     * Method to set the result components of the query.
     * @return The query
     */
    Query result(Expression... exprs);

    /**
     * Method to set a parameter value for use when executing the query.
     * @param paramExpr Parameter expression
     * @param value The value
     * @return The query
     */
    Query setParameter(Expression paramExpr, Object value);

    /**
     * Method to set a parameter value for use when executing the query.
     * @param paramName Parameter name
     * @param value The value
     * @return The query
     */
    Query setParameter(String paramName, Object value);

    /**
     * Method to execute the query where there are (potentially) multiple rows and we are returning either a
     * result type or the candidate type.
     * @param resultCls Result class
     * @return The results
     */
    <T> List<T> executeList(T resultCls);

    /**
     * Method to execute the query where there are (potentially) multiple rows and we have a result defined
     * but no result class.
     * @return The results
     */
    Object[] executeList();

    /**
     * Method to execute the query where there is a single row and we are returning either a result type
     * or the candidate type.
     * @param resultCls Result class
     * @return The result
     */
    <T> T executeUnique(T resultCls);

    /**
     * Method to execute the query where there is a single row and we have a result defined
     * but no result class.
     * @return The results
     */
    Object[] executeUnique();

    /**
     * Method to execute the query deleting the affected instances.
     * @return The number of objects deleted
     */
    long deletePersistentAll();

    /**
     * Method to return the equivalent String form of this query (if applicable for the query language).
     * @return The single-string form of this query
     */
    String toString();
}