/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import java.util.Map;
import java.util.Map.Entry;

import org.datanucleus.query.typesafe.BooleanExpression;
import org.datanucleus.query.typesafe.Expression;
import org.datanucleus.query.typesafe.MapExpression;
import org.datanucleus.query.typesafe.NumericExpression;

/**
 * Implementation of a MapExpression
 */
public class MapExpressionImpl<T extends Map<K, V>, K, V> extends ExpressionImpl<T> implements MapExpression<T, K, V>
{
    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#containsEntry(java.util.Map.Entry)
     */
    public BooleanExpression containsEntry(Entry<K, V> entry)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#containsEntry(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression containsEntry(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#containsKey(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression containsKey(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#containsKey(java.lang.Object)
     */
    public BooleanExpression containsKey(K key)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#containsValue(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression containsValue(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#containsValue(java.lang.Object)
     */
    public BooleanExpression containsValue(V value)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#isEmpty()
     */
    public BooleanExpression isEmpty()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.MapExpression#size()
     */
    public NumericExpression<Integer> size()
    {
        // TODO Auto-generated method stub
        return null;
    }
}