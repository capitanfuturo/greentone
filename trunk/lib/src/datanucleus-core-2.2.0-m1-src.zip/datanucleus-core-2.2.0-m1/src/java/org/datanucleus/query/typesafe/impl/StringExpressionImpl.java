/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import org.datanucleus.query.typesafe.BooleanExpression;
import org.datanucleus.query.typesafe.Expression;
import org.datanucleus.query.typesafe.NumericExpression;
import org.datanucleus.query.typesafe.StringExpression;

/**
 * Implementation of a StringExpression
 */
public class StringExpressionImpl<T> extends ComparableExpressionImpl<String> implements StringExpression<T>
{
    /**
     * Method to return an expression for this expression added to the passed expression (String concatenation).
     * @param expr The other expression
     * @return The summation
     */
    public StringExpression add(Expression expr)
    {
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#charAt(int)
     */
    public StringExpression charAt(int pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#charAt(org.datanucleus.query.typesafe.NumericExpression)
     */
    public StringExpression charAt(NumericExpression pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#endsWith(java.lang.String)
     */
    public BooleanExpression endsWith(String str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#endsWith(org.datanucleus.query.typesafe.StringExpression)
     */
    public BooleanExpression endsWith(StringExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#equalsIgnoreCase(java.lang.String)
     */
    public BooleanExpression equalsIgnoreCase(String str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#equalsIgnoreCase(org.datanucleus.query.typesafe.StringExpression)
     */
    public BooleanExpression equalsIgnoreCase(StringExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#indexOf(java.lang.String, int)
     */
    public NumericExpression indexOf(String str, int pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#indexOf(java.lang.String, org.datanucleus.query.typesafe.NumericExpression)
     */
    public NumericExpression indexOf(String str, NumericExpression pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#indexOf(java.lang.String)
     */
    public NumericExpression indexOf(String str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#indexOf(org.datanucleus.query.typesafe.StringExpression, int)
     */
    public NumericExpression indexOf(StringExpression expr, int pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#indexOf(org.datanucleus.query.typesafe.StringExpression, org.datanucleus.query.typesafe.NumericExpression)
     */
    public NumericExpression indexOf(StringExpression expr, NumericExpression pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#indexOf(org.datanucleus.query.typesafe.StringExpression)
     */
    public NumericExpression indexOf(StringExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#length()
     */
    public NumericExpression length()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#startsWith(java.lang.String)
     */
    public BooleanExpression startsWith(String str)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#startsWith(org.datanucleus.query.typesafe.StringExpression)
     */
    public BooleanExpression startsWith(StringExpression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#substring(int, int)
     */
    public StringExpression substring(int startPos, int endPos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#substring(int)
     */
    public StringExpression substring(int pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#substring(org.datanucleus.query.typesafe.NumericExpression, org.datanucleus.query.typesafe.NumericExpression)
     */
    public StringExpression substring(NumericExpression startPos, NumericExpression endPos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#substring(org.datanucleus.query.typesafe.NumericExpression)
     */
    public StringExpression substring(NumericExpression pos)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#toLowerCase()
     */
    public StringExpression toLowerCase()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#toUpperCase()
     */
    public StringExpression toUpperCase()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.StringExpression#trim()
     */
    public StringExpression trim()
    {
        // TODO Auto-generated method stub
        return null;
    }
}