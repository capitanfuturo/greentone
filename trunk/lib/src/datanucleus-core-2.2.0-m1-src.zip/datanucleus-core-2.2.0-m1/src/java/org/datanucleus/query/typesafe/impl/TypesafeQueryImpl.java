/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import java.util.List;

import javax.jdo.FetchPlan;

import org.datanucleus.ObjectManager;
import org.datanucleus.query.typesafe.BooleanExpression;
import org.datanucleus.query.typesafe.Expression;
import org.datanucleus.query.typesafe.NumericExpression;
import org.datanucleus.query.typesafe.OrderExpression;
import org.datanucleus.query.typesafe.PersistableExpression;
import org.datanucleus.query.typesafe.Query;

/**
 * Implementation of a typesafe Query.
 */
public class TypesafeQueryImpl implements Query
{
    ObjectManager om;
    Class candidateCls;

    /**
     * Constructor for a typesafe query.
     * @param om Object Manager
     */
    public TypesafeQueryImpl(ObjectManager om, Class cls)
    {
        this.om = om;
        this.candidateCls = cls;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#candidate()
     */
    public PersistableExpression candidate()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#parameter(java.lang.String, java.lang.Class)
     */
    public Expression parameter(String name, Class type)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#variable(java.lang.String, java.lang.Class)
     */
    public Expression variable(String name, Class type)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#filter(org.datanucleus.query.typesafe.BooleanExpression)
     */
    public Query filter(BooleanExpression expr)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#groupBy(org.datanucleus.query.typesafe.Expression[])
     */
    public Query groupBy(Expression... exprs)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#having(org.datanucleus.query.typesafe.Expression)
     */
    public Query having(Expression expr)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#orderBy(org.datanucleus.query.typesafe.OrderExpression[])
     */
    public Query orderBy(OrderExpression... orderExprs)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#range(long, long)
     */
    public Query range(long lowerIncl, long upperExcl)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#range(org.datanucleus.query.typesafe.NumericExpression, org.datanucleus.query.typesafe.NumericExpression)
     */
    public Query range(NumericExpression lowerInclExpr, NumericExpression upperExclExpr)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#range(java.lang.String, java.lang.String)
     */
    public Query range(String paramLowerIncl, String paramUpperExcl)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#result(org.datanucleus.query.typesafe.Expression[])
     */
    public Query result(Expression... exprs)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#setFetchPlan(javax.jdo.FetchPlan)
     */
    public Query setFetchPlan(FetchPlan fp)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#setParameter(org.datanucleus.query.typesafe.Expression, java.lang.Object)
     */
    public Query setParameter(Expression paramExpr, Object value)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#setParameter(java.lang.String, java.lang.Object)
     */
    public Query setParameter(String paramName, Object value)
    {
        // TODO Auto-generated method stub
        return this;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#executeList()
     */
    public Object[] executeList()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#executeList(java.lang.Object)
     */
    public <T> List<T> executeList(T resultCls)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#executeUnique()
     */
    public Object[] executeUnique()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#executeUnique(java.lang.Object)
     */
    public <T> T executeUnique(T resultCls)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Query#deletePersistentAll()
     */
    public long deletePersistentAll()
    {
        // TODO Auto-generated method stub
        return 0;
    }
}