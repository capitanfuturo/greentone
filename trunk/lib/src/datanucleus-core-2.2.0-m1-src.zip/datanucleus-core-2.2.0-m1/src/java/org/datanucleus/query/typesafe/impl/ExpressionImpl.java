/**********************************************************************
Copyright (c) 2010 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.query.typesafe.impl;

import org.datanucleus.query.typesafe.BooleanExpression;
import org.datanucleus.query.typesafe.Expression;
import org.datanucleus.query.typesafe.NumericExpression;
import org.datanucleus.query.typesafe.PersistableExpression;

/**
 * Implementation of the methods for Expression, to be extended by the XXXExpressionImpl classes.
 */
public class ExpressionImpl<T> implements Expression<T>
{
    /** The generic query expression that represents this typesafe expression. */
    org.datanucleus.query.expression.Expression queryExpr;

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#getParentExpression()
     */
    public PersistableExpression getParentExpression()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#name()
     */
    public String name()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#getType()
     */
    public Class<? extends T> getType()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#isParameter()
     */
    public boolean isParameter()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#isVariable()
     */
    public boolean isVariable()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#eq(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression eq(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#eq(java.lang.Object)
     */
    public BooleanExpression eq(T t)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#ne(org.datanucleus.query.typesafe.Expression)
     */
    public BooleanExpression ne(Expression expr)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#ne(java.lang.Object)
     */
    public BooleanExpression ne(T t)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#count()
     */
    public NumericExpression<T> count()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.datanucleus.query.typesafe.Expression#countDistinct()
     */
    public NumericExpression<T> countDistinct()
    {
        // TODO Auto-generated method stub
        return null;
    }
}