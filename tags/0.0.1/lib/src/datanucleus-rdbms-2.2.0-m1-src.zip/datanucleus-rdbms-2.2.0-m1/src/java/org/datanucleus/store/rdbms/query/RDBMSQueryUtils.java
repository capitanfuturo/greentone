/**********************************************************************
Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.store.rdbms.query;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.OMFContext;
import org.datanucleus.PersistenceConfiguration;
import org.datanucleus.exceptions.NucleusException;
import org.datanucleus.exceptions.NucleusUserException;
import org.datanucleus.metadata.AbstractClassMetaData;
import org.datanucleus.metadata.DiscriminatorMetaData;
import org.datanucleus.metadata.DiscriminatorStrategy;
import org.datanucleus.metadata.InheritanceStrategy;
import org.datanucleus.metadata.MetaDataUtils;
import org.datanucleus.query.QueryUtils;
import org.datanucleus.store.ExecutionContext;
import org.datanucleus.store.connection.ManagedConnection;
import org.datanucleus.store.mapped.DatastoreClass;
import org.datanucleus.store.mapped.DatastoreIdentifier;
import org.datanucleus.store.mapped.MappedStoreManager;
import org.datanucleus.store.mapped.StatementClassMapping;
import org.datanucleus.store.mapped.mapping.JavaTypeMapping;
import org.datanucleus.store.query.Query;
import org.datanucleus.store.rdbms.RDBMSStoreManager;
import org.datanucleus.store.rdbms.SQLController;
import org.datanucleus.store.rdbms.sql.DiscriminatorStatementGenerator;
import org.datanucleus.store.rdbms.sql.SQLStatement;
import org.datanucleus.store.rdbms.sql.StatementGenerator;
import org.datanucleus.store.rdbms.sql.UnionStatementGenerator;
import org.datanucleus.store.rdbms.sql.expression.StringLiteral;
import org.datanucleus.util.ClassUtils;
import org.datanucleus.util.Localiser;
import org.datanucleus.util.StringUtils;

/**
 * Utilities for use in queries specific to RDBMS.
 */
public class RDBMSQueryUtils extends QueryUtils
{
    /** Localiser of messages. */
    protected static final Localiser LOCALISER_RDBMS = Localiser.getInstance(
        "org.datanucleus.store.rdbms.Localisation", RDBMSStoreManager.class.getClassLoader());

    /**
     * Convenience method that takes a result set that contains a discriminator column and returns
     * the class name that it represents.
     * @param discrimMapping Mapping for the discriminator column
     * @param dismd Metadata for the discriminator
     * @param rs The result set
     * @param ec execution context
     * @return The class name for the object represented in the current row
     */
    public static String getClassNameFromDiscriminatorResultSetRow(JavaTypeMapping discrimMapping,
            DiscriminatorMetaData dismd, ResultSet rs, ExecutionContext ec)
    {
        String rowClassName = null;
        
        if (discrimMapping != null && dismd.getStrategy() != DiscriminatorStrategy.NONE)
        {
            try
            {
                String discriminatorColName = discrimMapping.getDatastoreMapping(0).getDatastoreField().getIdentifier().getIdentifierName();
                String discriminatorValue = rs.getString(discriminatorColName);
                rowClassName = MetaDataUtils.getClassNameFromDiscriminatorValue(discriminatorValue, dismd, ec);
            }
            catch (SQLException e)
            {
                // discriminator column doesn't exist with this name
            }
        }
        return rowClassName;
    }

    /**
     * Accessor for the result set type for the specified query.
     * Uses the persistence property "datanucleus.rdbms.query.resultSetType" and allows it to be
     * overridden by the query extension of the same name.
     * Checks both the PMF, and also the query extensions.
     * @param query The query
     * @return The result set type string
     */
    public static String getResultSetTypeForQuery(Query query)
    {
        String propName = "datanucleus.rdbms.query.resultSetType";
        String rsTypeString = 
            query.getObjectManager().getOMFContext().getPersistenceConfiguration().getStringProperty(propName);
        Object rsTypeExt = query.getExtension(propName);
        if (rsTypeExt != null)
        {
            rsTypeString = (String)rsTypeExt;
        }
        return rsTypeString;
    }

    /**
     * Accessor for the result set concurrency for the specified query.
     * Uses the persistence property "datanucleus.rdbms.query.resultSetConcurrency" and allows it to be
     * overridden by the query extension of the same name.
     * Checks both the PMF, and also the query extensions.
     * @param query The query
     * @return The result set concurrency string
     */
    public static String getResultSetConcurrencyForQuery(Query query)
    {
        String propName = "datanucleus.rdbms.query.resultSetConcurrency";
        String rsConcurrencyString = 
            query.getObjectManager().getOMFContext().getPersistenceConfiguration().getStringProperty(propName);
        Object rsConcurrencyExt = query.getExtension(propName);
        if (rsConcurrencyExt != null)
        {
            rsConcurrencyString = (String)rsConcurrencyExt;
        }
        return rsConcurrencyString;
    }

    /**
     * Convenience method to return if the specified query should use an "UPDATE" lock on returned objects.
     * First checks whether serializeRead is set on the query and, if not, falls back to the setting
     * for the class.
     * @param query The query
     * @return Whether to use an "UPDATE" lock
     */
    public static boolean useUpdateLockForQuery(Query query)
    {
    	if (query.getSerializeRead() != null)
    	{
    	    // Query value takes top priority
            return query.getSerializeRead();
    	}
    	else
        {
    	    // Fallback to transaction or class itself
            return query.getObjectManager().getSerializeReadForClass(query.getCandidateClassName());
        }
    }

    /**
     * Method to create a PreparedStatement for use with the query.
     * @param conn the Connection
     * @param queryStmt The statement text for the query
     * @param query The query
     * @return the PreparedStatement
     * @throws SQLException Thrown if an error occurs creating the statement
     */
    public static PreparedStatement getPreparedStatementForQuery(ManagedConnection conn, String queryStmt, 
            Query query)
    throws SQLException
    {
        ExecutionContext ec = query.getObjectManager();

        // Apply any non-standard result set definition if required (either from the PMF, or via query extensions)
        String rsTypeString = RDBMSQueryUtils.getResultSetTypeForQuery(query);
        if (rsTypeString != null &&
            (!rsTypeString.equals("scroll-sensitive") && !rsTypeString.equals("forward-only") &&
             !rsTypeString.equals("scroll-insensitive")))
        {
            throw new NucleusUserException(LOCALISER.msg("052510"));
        }

        String rsConcurrencyString = RDBMSQueryUtils.getResultSetConcurrencyForQuery(query);
        if (rsConcurrencyString != null &&
            (!rsConcurrencyString.equals("read-only") && !rsConcurrencyString.equals("updateable")))
        {
            throw new NucleusUserException(LOCALISER.msg("052511"));
        }

        SQLController sqlControl = ((RDBMSStoreManager)ec.getStoreManager()).getSQLController();
        PreparedStatement ps = sqlControl.getStatementForQuery(conn, queryStmt, rsTypeString, rsConcurrencyString);

        return ps;
    }

    /**
     * Method to apply any restrictions to the created ResultSet.
     * @param ps The PreparedStatement
     * @param query The query
     * @param applyTimeout Whether to apply the query timeout (if any) direct to the PreparedStatement
     * @throws SQLException Thrown when an error occurs applying the constraints
     */
    public static void prepareStatementForExecution(PreparedStatement ps, Query query, boolean applyTimeout)
    throws SQLException
    {
        OMFContext omfCtx = query.getObjectManager().getOMFContext();
        MappedStoreManager storeMgr = (MappedStoreManager)omfCtx.getStoreManager();
        PersistenceConfiguration conf = omfCtx.getPersistenceConfiguration();

        if (applyTimeout)
        {
            Integer timeout = query.getDatastoreReadTimeoutMillis();
            if (timeout != null && timeout > 0)
            {
                ps.setQueryTimeout(timeout/1000);
            }
        }

        // Apply any fetch size
        int fetchSize = 0;
        if (query.getFetchPlan().getFetchSize() > 0)
        {
            // FetchPlan has a size set so use that
            fetchSize = query.getFetchPlan().getFetchSize();
        }
        if (storeMgr.getDatastoreAdapter().supportsQueryFetchSize(fetchSize))
        {
            ps.setFetchSize(fetchSize);
        }

        // Apply any fetch direction
        String propName = "datanucleus.rdbms.query.fetchDirection";
        String fetchDir = conf.getStringProperty(propName);
        Object fetchDirExt = query.getExtension(propName);
        if (fetchDirExt != null)
        {
            fetchDir = (String)fetchDirExt;
            if (!fetchDir.equals("forward") && !fetchDir.equals("reverse") && !fetchDir.equals("unknown"))
            {
                throw new NucleusUserException(LOCALISER.msg("052512"));
            }
        }

        if (fetchDir.equals("reverse"))
        {
            ps.setFetchDirection(ResultSet.FETCH_REVERSE);
        }
        else if (fetchDir.equals("unknown"))
        {
            ps.setFetchDirection(ResultSet.FETCH_UNKNOWN);
        }

        // Add a limit on the number of rows to include the maximum we may need
        long toExclNo = query.getRangeToExcl();
        if (toExclNo != 0 && toExclNo != Long.MAX_VALUE)
        {
            if (toExclNo > Integer.MAX_VALUE)
            {
                // setMaxRows takes an int as input so limit to the correct range
                ps.setMaxRows(Integer.MAX_VALUE);
            }
            else
            {
                ps.setMaxRows((int)toExclNo);
            }
        }
    }

    /**
     * Method to return a statement selecting the candidate table(s) required to cover all possible
     * types for this candidates inheritance strategy.
     * @param parentStmt Parent statement (if there is one)
     * @param cmd Metadata for the class
     * @param clsMapping Mapping for the results of the statement
     * @param ec ObjectManager
     * @param candidateCls Candidate class
     * @param subclasses Whether to create a statement for subclasses of the candidate too
     * @param result The result clause
     * @param candidateAlias alias for the candidate (if any)
     * @param candidateTableGroupName TableGroup name for the candidate (if any)
     * @return The SQLStatement
     * @throws NucleusException if there are no tables for concrete classes in this query (hence would return null)
     */
    public static SQLStatement getStatementForCandidates(SQLStatement parentStmt, AbstractClassMetaData cmd, 
            StatementClassMapping clsMapping, ExecutionContext ec, Class candidateCls, boolean subclasses, 
            String result, String candidateAlias, String candidateTableGroupName)
    {
        SQLStatement stmt = null;

        RDBMSStoreManager storeMgr = (RDBMSStoreManager)ec.getStoreManager();
        DatastoreIdentifier candidateAliasId = null;
        if (candidateAlias != null)
        {
            candidateAliasId = storeMgr.getIdentifierFactory().newDatastoreContainerIdentifier(candidateAlias);
        }

        ClassLoaderResolver clr = ec.getClassLoaderResolver();
        DatastoreClass candidateTable = storeMgr.getDatastoreClass(cmd.getFullClassName(), clr);
        List<DatastoreClass> candidateTables = new ArrayList<DatastoreClass>();
        if (cmd.getInheritanceMetaData().getStrategy() == InheritanceStrategy.COMPLETE_TABLE)
        {
            if (candidateTable != null)
            {
                candidateTables.add(candidateTable);
            }
            if (subclasses)
            {
                HashSet<String> subclassNames = 
                    storeMgr.getSubClassesForClass(cmd.getFullClassName(), subclasses, clr);
                if (subclassNames != null)
                {
                    Iterator<String> subclassIter = subclassNames.iterator();
                    while (subclassIter.hasNext())
                    {
                        String subclassName = subclassIter.next();
                        DatastoreClass tbl = storeMgr.getDatastoreClass(subclassName, clr);
                        if (tbl != null)
                        {
                            candidateTables.add(tbl);
                        }
                    }
                }
            }

            Iterator<DatastoreClass> iter = candidateTables.iterator();
            int maxClassNameLength = cmd.getFullClassName().length();
            while (iter.hasNext())
            {
                DatastoreClass cls = iter.next();
                String className = cls.getType();
                if (className.length() > maxClassNameLength)
                {
                    maxClassNameLength = className.length();
                }
            }

            iter = candidateTables.iterator();
            while (iter.hasNext())
            {
                DatastoreClass cls = iter.next();

                SQLStatement tblStmt =
                    new SQLStatement(parentStmt, storeMgr, candidateTable, candidateAliasId, candidateTableGroupName);
                tblStmt.setClassLoaderResolver(clr);
                tblStmt.setCandidateClassName(cls.getType());

                // Add SELECT of dummy column accessible as "NUCLEUS_TYPE" containing the classname
                JavaTypeMapping m = storeMgr.getMappingManager().getMapping(String.class);
                String nuctypeName = cls.getType();
                if (maxClassNameLength > nuctypeName.length())
                {
                    nuctypeName = StringUtils.leftAlignedPaddedString(nuctypeName, maxClassNameLength);
                }
                StringLiteral lit = new StringLiteral(tblStmt, m, nuctypeName, null);
                tblStmt.select(lit, UnionStatementGenerator.NUC_TYPE_COLUMN);

                if (stmt == null)
                {
                    stmt = tblStmt;
                }
                else
                {
                    stmt.union(tblStmt);
                }
            }
            clsMapping.setNucleusTypeColumnName(UnionStatementGenerator.NUC_TYPE_COLUMN);
        }
        else
        {
            // "new-table", "superclass-table", "subclass-table"
            List<Class> candidateClasses = new ArrayList<Class>();
            if (ClassUtils.isReferenceType(candidateCls))
            {
                // Persistent interface
                String[] clsNames =
                    storeMgr.getOMFContext().getMetaDataManager().getClassesImplementingInterface(candidateCls.getName(), clr);
                for (int i=0;i<clsNames.length;i++)
                {
                    Class cls = clr.classForName(clsNames[i]);
                    DatastoreClass table = storeMgr.getDatastoreClass(clsNames[i], clr);
                    candidateClasses.add(cls);
                    candidateTables.add(table);
                }
            }
            else if (candidateTable != null)
            {
                // Candidate has own table
                candidateClasses.add(candidateCls);
                candidateTables.add(candidateTable);
            }
            else
            {
                // Candidate stored in subclass tables
                AbstractClassMetaData[] cmds = storeMgr.getClassesManagingTableForClass(cmd, clr);
                if (cmds != null && cmds.length > 0)
                {
                    for (int i=0;i<cmds.length;i++)
                    {
                        DatastoreClass table = storeMgr.getDatastoreClass(cmds[i].getFullClassName(), clr);
                        Class cls = clr.classForName(cmds[i].getFullClassName());
                        candidateClasses.add(cls);
                        candidateTables.add(table);
                    }
                }
                else
                {
                    throw new UnsupportedOperationException("No tables for query of " + cmd.getFullClassName());
                }
            }

            for (int i=0;i<candidateTables.size();i++)
            {
                DatastoreClass tbl = candidateTables.get(i);
                Class cls = candidateClasses.get(i);

                StatementGenerator stmtGen = null;
                if (tbl.getDiscriminatorMapping(true) != null || QueryUtils.resultHasOnlyAggregates(result))
                {
                    // Either has a discriminator, or only selecting aggregates so need single select
                    stmtGen = new DiscriminatorStatementGenerator(storeMgr, clr, cls, subclasses, 
                        candidateAliasId, candidateTableGroupName);
                }
                else
                {
                    stmtGen = new UnionStatementGenerator(storeMgr, clr, cls, subclasses, 
                        candidateAliasId, candidateTableGroupName);
                    if (result == null)
                    {
                        // Returning one row per candidate so include distinguisher column
                        stmtGen.setOption("selectNucleusType");
                        clsMapping.setNucleusTypeColumnName(UnionStatementGenerator.NUC_TYPE_COLUMN);
                    }
                }
                stmtGen.setParentStatement(parentStmt);
                SQLStatement tblStmt = stmtGen.getStatement();

                if (stmt == null)
                {
                    stmt = tblStmt;
                }
                else
                {
                    stmt.union(tblStmt);
                }
            }
        }

        return stmt;
    }
}