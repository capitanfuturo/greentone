package org.datanucleus.store.rdbms.scostore;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.store.mapped.scostore.JoinArrayStoreSpecialization;
import org.datanucleus.store.rdbms.RDBMSStoreManager;
import org.datanucleus.util.Localiser;

/**
 * RDBMS-specific implementation of a {@link JoinArrayStoreSpecialization}.
 */
public class RDBMSJoinArrayStoreSpecialization extends RDBMSAbstractArrayStoreSpecialization implements JoinArrayStoreSpecialization
{
    RDBMSJoinArrayStoreSpecialization(Localiser localiser, ClassLoaderResolver clr, RDBMSStoreManager storeMgr)
    {
        super(localiser, clr, storeMgr);
    }
}
